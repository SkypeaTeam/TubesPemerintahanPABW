	<style type="text/css" media="screen">
		.footer{
	     background-color: #333;
	     padding: 5px;
        }
       .footer .copy{
	    color: #eaeaea;
	    text-align: center;
	    font-size: 15px;
        }
        .footer_contact{
         margin-top: 100px;
	     background-color: #333;
	     padding: 5px;
	     margin-top: 100px;

        }
        .footer_contact .i{
        	text-align: center;
		    color: #eaeaea;
		    font-size: 15px;
            margin-right: 20px;
            margin-left: 70px;


        }
        .footer_contact .ia{
            text-align: center;
            color: #eaeaea;
            font-size: 20px;
        }
        .footer_contact .ib{
            text-align: center;
            color: #eaeaea;
            font-size: 15px;
        }        
	</style>
		</div>
		<script>
                CKEDITOR.replace( 'editor1' );
            </script>
            <div class="footer_contact">
            	<h1 class="ia"><img src="http://localhost/ciblog/assets/images/logo2.png" alt=""></h1>
                <p class="ia">we're based in lampung selatan,sumatra</p>
                <p class="ib">we work with clients from all over.get in touch with us!</p>
            	<a href="" title="" class="i"><img src="http://localhost/ciblog/assets/images/location.png" alt=""> Jalan Terusan Ryacudu, Way Hui , Jati Agung, Way Huwi.</a>
                <a href="" title="" class="i"><img src="http://localhost/ciblog/assets/images/contact.png" alt=""> 333 333 333 333</a>
            	<a href="" title="" class="i"><img src="http://localhost/ciblog/assets/images/email.png" alt="">  pemerintahan_skypea@skypea.go.id</a>
            	
                

            </div>

            <div class="footer">
            	<p class="copy">Copyright © skypea.go.id</p>
            </div>
	</body>
</html>