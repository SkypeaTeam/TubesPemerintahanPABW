<!DOCTYPE html>
<html>
<head>
	<title>pabw.go.id</title>
	<link rel="stylesheet" href="<?php echo base_url('assets4/style.css'); ?>">
</head>
<body>
	<div class="bg">
		<div class="logo">
					<h1><img src="http://localhost/ciblog/assets4/images/logo.png"></h1>
		</div>

		<h1><marquee behavior="scroll" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" direction="left">Potensi Daerah
			</marquee></h1>

		<div id="header">
			<div>
				<nav id="nav">
					<ul>
						<li class="active"><a href="<?php echo base_url(); ?>potensi">Pariwisata</a></li>
						<li ><a href="<?php echo base_url(); ?>peternakan">Peternakan</a></li>
						<li ><a href="<?php echo base_url(); ?>pertanian">Pertanian</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<div id="content" class="8u skel-cell-important">
						<section>
							<header>
								<h2>Pariwisata Daerah Skypea</h2>
								<span class="byline">Potensi Di Bidang Pariwisata</span>
							</header>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/pariwisata2.png" alt="" /></a>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/pariwisata1.png" alt="" /></a>
							<br><br>
							<p>Bidang pariwisata <strong>Daerah Skypea</strong>, merupakan salah satu sektor ekonomi potensial yang dimiliki Daerah Skypea untuk dikembangkan sebagai sumber penghasilan guna meningkatkan Pendapatan Asli Daerah (PAD). Dengan membaiknya kondisi perekonomian serta jaminan keamanan akan memberikan dampak positif terhadap peningkatan wisatawan di wilayah Daerah Skypea. &ndash; Keindahan alam dan keanekaragaman adat dan budaya merupakan modal dasar yang dapat dikembangkan menjadi produk wisata menarik bagi wisatawan.
							<p>Hal ini lah yang merupakan tantangan sekaligus peluang bagi para investor untuk dapat memanfaatkan potensi pariwisata yang ada di Daerah Skype. Dengan pengelolaan yang baik dan optimal, ditambah dengan pembangunan sarana dan prasarana di sekitar objek wisata, akan menambah daya tarik bagi para wisatawan </p>
						</section>
					</div>
</body>
</html>