<!DOCTYPE html>
<html>
<head>
	<title>pabw.go.id</title>
	<link rel="stylesheet" href="http://localhost/ciblog/assets5/style.css">
</head>
<body>
	<div class="logo">
					<h1><img src="http://localhost/ciblog/assets5/image/logo.png" width="400px"></h1>
		</div>
	<div class="bg_content">
		<div class="text">
		<h2 align="right"><a href="<?php echo base_url(); ?>layanan">BACK</a></h2>
		<br><br><h2 align="center">AKTA PERCERAIAN</h2>
		<p align="center">Selasa, 31 Oktober 2018 01:45 WIB</p></br>
		
		<h2>Lokasi Pelayanan : Kantor Dinas/Suku Dinas Kependudukan dan Pencatatan Sipil</h2>
		<h2>Waktu Pelayanan : 5 hari kerja sejak tanggal diterimanya berkas persyaratan secara lengkap
</h2>
		<h2>Biaya : Gratis</h2>

		<p>Sesuai dengan Undang-Undang No. 24 Tahun 2013 tentang Perubahan atas Undang-Undang No. 23 Tahun 2006 pencatatan perceraian yang sebelumnya berdasarkan atas asa peristiwa, sejak ditetapkannya undang-undang ini berubah menjadi berdasarkan atas domisli. Sehingga pencatatan dilakukan pada instansi pelaksanan sesuai dengan domisili pelapor.<br><br>
 
Peristiwa perceraian yang telah mendapat keputusan Pengadilan Negeri dan telah mempunyai kekuatan hukum tetap wajib dicatatkan pada Dinas bagi Orang Asing dan pada Suku Dinas bagi WNI, paling lambat 60 (enam puluh) hari sejak Putusan Pengadilan tentang perceraian yang telah memperoleh kekuatan hukum tetap.<br><br>
 
Dinas Kependudukan dan Catatan Sipil hanya melayani Pencatatan Perceraian bagi perkawinan yang telah dilangsungkan menurut Tata Cara/Hukum Agama selain agama Islam dan telah memperoleh Keputusan Pengadilan Negeri.</p><br>


<h2 align="center">Blangko Kutipan Akta Cerai</h2>

					<h1><img src="http://localhost/ciblog/assets5/image/c.jpg" width="200px"></h1>

<h2>Persyaratan</h2>
<p>Untuk mendapatkan pelayanan ini harus memenuhi persyaratan berikut :<br>
a. Keputusan Pengadilan yang mempunyai kekualan hukum lelap;<br>
b. Asli dan Fotokopi Kutipan Akta Perkawinan;<br>
c. Asli dan Fotokopi KK dan KTP; dand. Bagi Orang Asing melampirkan Asli dan Fotokopi dokumen antara lain:<br>
1. Paspor; dan<br>
2. Dokumen Imigrasi.</p>

</body>
</html>