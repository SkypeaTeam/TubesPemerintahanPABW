<!DOCTYPE html>
<html>
<head>
	<title>pabw.go.id</title>
	<link rel="stylesheet" href="<?php echo base_url('assets4/style.css'); ?>">
</head>
<body>
	<div class="bg">
		<div class="logo">
					<h1><img src="http://localhost/ciblog/assets4/images/logo.png"></h1>
		</div>

		<h1><marquee behavior="scroll" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" direction="left">Potensi Daerah
			</marquee></h1>

		<div id="header">
			<div>
				<nav id="nav">
					<ul>
						<li ><a href="<?php echo base_url(); ?>potensi">Pariwisata</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>peternakan">Peternakan</a></li>
						<li ><a href="<?php echo base_url(); ?>pertanian">Pertanian</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<div id="content" class="8u skel-cell-important">
						<section>
							<header>
								<h2>Peternakan Daerah Skypea</h2>
								<span class="byline">Potensi Di Bidang Peternakan</span>
							</header>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/peternakan1.png" alt="" /></a>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/peternakan2.png" alt="" /></a>
							<br><br>
							<p>Bidang peternakan <strong>Daerah Skypea</strong>, Populasi ternak besar di Daerah Skypea pada tahun 2012 mencapai 8.136 hewan ternak yang terdiri dari 5.981 ternak sapi dan 2.155 ternak kerbau. Kecamatan Sumberejo merupakan kecamatan dengan populasi ternak sapi terbanyak (1.375 ekor) sedangkan untuk kerbau paling banyak terdapat di Daerah Wakanda (305 ekor). Populasi ternak kecil sebesar 171.230 ekor yang terdiri dari 164.325 ternak kambing dan 6.905 ternak domba.
							<p>Kecamatan gisting dan sumberejo dapat dikatakan sebagai sentra ternak kambing dengan populasi ternak mencapai 13,77 dan 13,53 persen. Kecamatan gisting merupakan Kecamatan dengan populasi ternak unggas terbesar dengan 24,71 persen. Populasi ternak unggas juga berpengaruh terhadap produksi telur, Kecamatan Gisting menyuplai telur sebanyak 19.68 persen dari total produksi telur di Daerah Skypea.</p>
							<p>Daerah Skypea juga merupakan wilayah yang memiliki laut, sehingga sebagianmasyarakat berkerja di sector perikanan, khususnya perikanan laut. Jumlah nelayanTangkap di Daerah Skypea pada tahun 2012 sebanyak 5.480 orang, dengan jumlah nelayan di kecamatan Kota Agung yang paling banyak dari kecamatan lainnya. Dari sisi Produksi, Daerah Wakanda Agung juga mempunyai nilai produksi terbesar mencapai 40.34 persen (10.868,65) dari total produksi di Daerah Skypea yang mencapai 26.941,81 ton pada tahun 2012. Selain sektor perikanan laut, budidaya perikanan darat juga ada di Daerah Skypea, dengan luas lahan mencapai 2.407 ha.</p>
						</section>
					</div>
</body>
</html>