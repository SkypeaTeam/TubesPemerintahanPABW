<!DOCTYPE html>
<html>
<head>
	<title>Potensi Daerah</title>
	<link rel="stylesheet" href="http://localhost/ciblog/assets4/stylDaerah Skypeae.css">
</head>
<body>
	
		<div class="logo1">
		<h1><img src="http://localhost/ciblog/assets4/images/logo.png"></h1>
		</div>
		<div class="bg_content">
		<h2 align="right"><a href="<?php echo base_url(); ?>potensi">BACK</a></h2>
		<h2 align="center">Pariwisata Skypea</h2>
		<p align="center">Tahun 2xxx</p></br>
		<img src="http://localhost/ciblog/assets4/images/pariwisata.jpg">

		<h2>Potensi Di Bidang Pariwisata</h2></br>
		<p>Bidang pariwisata merupakan salah satu sektor ekonomi potensial yang dimiliki Daerah Skypea untuk dikembangkan sebagai sumber penghasilan guna meningkatkan Pendapatan Asli Daerah (PAD). Dengan membaiknya kondisi perekonomian serta jaminan keamanan akan memberikan dampak positif terhadap peningkatan wisatawan di wilayah Daerah Skypea. </p>

		<p>Keindahan alam dan keanekaragaman adat dan budaya merupakan modal dasar yang dapat dikembangkan menjadi produk wisata menarik bagi wisatawan.</p>

		<p>Hal ini lah yang merupakan tantangan sekaligus peluang bagi para investor untuk dapat memanfaatkan potensi pariwisata yang ada di Daerah Skype. Dengan pengelolaan yang baik dan optimal, ditambah dengan pembangunan sarana dan prasarana di sekitar objek wisata, akan menambah daya tarik bagi para wisatawan</p>
	</div>

	
	
</body>
</html>