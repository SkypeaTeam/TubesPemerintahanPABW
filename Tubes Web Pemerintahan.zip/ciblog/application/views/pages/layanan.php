<!DOCTYPE html>
<html>
<head>
	<title>pabw.go.id</title>
	<link rel="stylesheet" href="http://localhost/ciblog/assets5/style.css">
</head>
<body>
	<div class="bg">
		<div class="logo">
					<h1><img src="http://localhost/ciblog/assets5/image/logo.png" width="300px"></h1>
		</div><br><br><br>
		<div class="logo1">
					<h2><img src="http://localhost/ciblog/assets5/image/layananlogo.png" width="500px"></h2>
		</div><br><br><br><br><br><br><br>
		<div id="header">
			<div>
				<nav id="nav">
					<ul>
						<li class="active"><a href="<?php echo base_url(); ?>kelahiran">Akta Kelahiran</a></li>
						<li><a href="<?php echo base_url(); ?>perceraian">Akta Perceraian</a></li>
						<li><a href="<?php echo base_url(); ?>perkawinan">Akta Perkawinan</a></li>
						<li><a href="<?php echo base_url(); ?>kk">Kartu Keluarga (KK)</a></li>
						<li><a href="<?php echo base_url(); ?>kelahiran">Kartu Tanda Penduduk (KTP)</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
</div>
</body>
</html>