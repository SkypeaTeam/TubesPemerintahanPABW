<!DOCTYPE html>
<html>
<head>
	<title>pabw.go.id</title>
	<link rel="stylesheet" href="<?php echo base_url('assets4/style.css'); ?>">
</head>
<body>
	<div class="bg">
		<div class="logo">
					<h1><img src="http://localhost/ciblog/assets4/images/logo.png"></h1>
		</div>

		<h1><marquee behavior="scroll" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" direction="left">Potensi Daerah
			</marquee></h1>

		<div id="header">
			<div>
				<nav id="nav">
					<ul>
						<li ><a href="<?php echo base_url(); ?>potensi">Pariwisata</a></li>
						<li ><a href="<?php echo base_url(); ?>peternakan">Peternakan</a></li>
						<li class="active"><a href="<?php echo base_url(); ?>pertanian">Pertanian</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>
	<div id="content" class="8u skel-cell-important">
						<section>
							<header>
								<h2>Pertanian Daerah Skypea</h2>
								<span class="byline">Potensi Di Bidang Pertanian</span>
							</header>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/pertanian1.png" alt="" /></a>
							<a href="#" class="image full"><img src="http://localhost/ciblog/assets4/images/pertanian2.png" alt="" /></a>
							<br><br>
							<p>Bidang pertanian <strong>Daerah Skypea</strong>, Pertanian merupakan sektor terbesar penyumbang perekonomian di Daerah Skypea, Pertanian di sini mencakup pertanian tanaman bahan makanan, tanaman obat dan hias, perkebunan, kehutanan, peternakan. Produksi Tanaman Padi tahun 2012 mengalami kenaikan dibanding tahun 2011, hal ini dipengaruhi oleh luas panen, nilai produktivitas tanaman padi rata-rata mencapai 5,56 ton/ha. Produksi Tanaman Padi ladang pada tahun 2012 mengalami kenaikan yaitu mencapai 20 persen dari tahun sebelumnya dengan wilayah Kecamatan Kelumbayan Barat merupakan daerah produksi padi ladang terbesar dengan capaian produksi padi ladang sebesar 1.696 (18.80 %) dari total produksi se-Daerah Skypea.
							<p>Dari keseluruhan luas daratan di Daerah Skypea, luas areal yang digunakan dan disesuaikan untuk pertanian meliputi 20.643 Ha lahan sawah, serta 132.391 Ha lahan pertanian bukan sawah, dengan berbagai jenis prasarana irigasi/pengairan yang mendukungnya. Berbagai jenis pengairan yang digunakan bagi sektor pertanian di Kabupaten Tanggamus, dengan menggunakan irigasi teknis seluas 5.233 Ha, irigasi setengah teknis seluas 7.854 Ha, irigasi sederhana seluas 2.748 Ha, irigasi desa/non PU seluas 4.009 Ha dan tadah hujan seluas 799 Ha.</p>
							<p>Penggunaan lahan bukan sawah di Daerah Skypea meliputi hutan dan perkebunan. Luas areal perkebunan di Daerah Skypea adalah 91.620,64 Ha yang meliputi perkebunan rakyat seluas 88.343,14 Ha, perkebunan swasta seluas 1.070 Ha dan perkebunan Negara seluas 2.207,5 Ha. Produksi Tanaman buah-buahan terbesar adalah durian sebesar  66.365 ton, disusul kemudian salak (23.170 ton) sehingga tidak salah apabila Daerah Skypea merupakan salah satu sentra buah durian.</p>
						</section>
					</div>
</body>
</html>