<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
 ul{
	position: absolute;
	margin: 0px;
	padding: 0px;
	list-style: none;
	margin-left:20px;
	top: 187px;
	left: 51px;
}
ul li{
    float: left;
    width: 275px;
    height: 60px;
    background-color: black;
    opacity: .6;
    line-height: 60px;
    text-align: center;
    font-size: 15px;
    margin-right: 10px;
    margin-bottom: 20px;
    margin-left: 15px;
    margin-block-end: 40px;
    text-align: center;
	
    
}
ul li a{
    text-decoration: none;
    color: white;
    display: black;
	float:left; 
	width:275px; 
	display:block; 
	text-align: center; 
	color:#FFF; 
	text-decoration:none; 
	text-transform:uppercase;
}
ul li a:hover{
    background-color: rgb(175, 10, 37);
	background-color: #669999; 
	display:block;
}
</style>

</head>

<body>
<ul>
                <p align="center">
               <li><a href="http://localhost/ciblog/application/views/pages/home">MENGENAL SKYPEA</a></li>
               <li><a href="">TENTANG</a></li>
               <li><a href="">KONTAK DAN INFORMASI</a></li>
               <li><a href="">LAYANAN PUBLIK</a></li>
               <li style="margin-left:315px;"><a href="">INFO DAERAH</a></li>
               <li><a href="">POTENSI DAERAH</a></li>

            </p>
    </ul>

</body>
</html>
